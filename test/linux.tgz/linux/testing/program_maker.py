from collections import defaultdict
from dataclasses import dataclass
from functools import reduce
from os import O_RDONLY, O_RDWR, O_WRONLY
from typing import Callable, Optional

from tests.spec import ProgramMakerTextProducer
from testing.enums import FileFlags, XattrFlags

@dataclass
class MonitoredExeFile:
    path: str

@dataclass
class Expression:
    text: str

class ProgramMaker(ProgramMakerTextProducer):

    # NB: all number-like parameters with type str is c-expressions

    def __init__(self):
        self.includes = set[str]()
        self.declarations = set[str]()
        self.syscall_lines = list[str]()
        self._vars_count: dict[str, int] = defaultdict(int)

    def get_text(self):
        nl = '\n'
        self.includes.add('#include <stdio.h>')
        self.includes.add('#include <sys/types.h>')
        self.includes.add('#include <sys/stat.h>')
        self.includes.add('#include <unistd.h>')
        return f'''
            #define _GNU_SOURCE
            #define STRINGIZE(x) STRINGIZE2(x)
            #define STRINGIZE2(x) #x
            #define LINE_STRING STRINGIZE(__LINE__)
            {nl.join(self.includes)}
            int main(int argc, char *argv[], char *envp[]) {{
                {nl.join(self.declarations)}
                printf("{{"
                    "\\"syscall\\": \\"execve\\", "
                    "\\"ret\\": 0, "
                    "\\"pathname\\": \\"%s\\","
                    "\\"pid\\": %d"
                    "}}", argv[0], getpid());
                {nl.join(self.syscall_lines)}
                return 0;
            }}'''
    
    def _bound_value(self, type: Callable[[str], str], prefix: str = 'var', init: Optional[str] = None):
        name = f'{prefix}{self._vars_count[prefix]}'
        self._vars_count[prefix] += 1
        self.declarations.add(f'{type(name)} {init or ""};')
        return Expression(name)

    def bound_value_as_uid_t(self, init: Optional[Expression] = None, prefix: str = 'uid'):
        return self._bound_value(
            type = lambda uid: f'uid_t {uid}',
            prefix = prefix,
            init = f'= {init.text}' if init is not None else None)

    def bound_value_as_int(self, init: Optional[int] = None, prefix: str = 'num'):
        return self._bound_value(
            type = lambda num: f'int {num}',
            prefix = prefix,
            init = f'= {init}' if init is not None else None)

    def bound_value_as_charparray(self, init: Optional[list[str]] = None, prefix: str = 'strings'):
        assert init is None or all('"' not in s for s in init)
        q = '"'
        return self._bound_value(
            type = lambda strings: f'char *{strings}[]',
            prefix = prefix,
            init = f' = {{{"".join([f"{q}{s}{q}, " for s in init])}NULL}}' if init is not None else None)

    def bound_value_as_chararray(self, size: Optional[int] = None, init: Optional[str] = None, prefix: str = 'buf'):
        return self._bound_value(
            type = lambda string: f'char {string}[{str(size) if size is not None else ""}]',
            prefix = prefix,
            init = f' = "{init}"' if init is not None else None)


    def xgetenv(self, var: str):
        assert '"' not in var
        self.includes.add('#include <stdlib.h>')
        return Expression(f'''({{
            char *val = getenv("{var}");
            if (!val) exit(15);
            val;
            }})''')

    def to_int(self, arg: Expression, base: int = 10):
        self.includes.add('#include <stdlib.h>')
        return Expression(f'strtol({arg.text}, 0, {base})')


    def open(self, pathname: str, flags: int, mode: int, fatal: bool = False):
        assert '"' not in pathname

        self.includes.add('#include <fcntl.h>')
        self.includes.add('#include <unistd.h>')
        self.includes.add('#include <sys/syscall.h>')
        self.includes.add('#include <sys/stat.h>')
        self.includes.add('#include <sys/types.h>')
        flags_expr = self.openflags2expr(flags)
        syscall = f'syscall(SYS_open, "{pathname}", {flags_expr.text}, 0{mode:0o})'

        fd = self.bound_value_as_int(prefix='fd')

        if fatal:

            self.includes.add('#include <stdio.h>')
            self.includes.add('#include <sys/types.h>')
            self.includes.add('#include <unistd.h>')
            line1 = f'if (({fd.text} = {syscall}) < 0) {{ perror(__FILE__ ":" LINE_STRING ":" "{pathname}"); return 2; }}'
        
        else:

            self.includes.add("#include <sys/types.h>")
            self.includes.add("#include <unistd.h>")
            self.includes.add('#include <stdio.h>')
            line1 = f'{fd.text} = {syscall};'

        self.includes.add("#include <sys/types.h>")
        self.includes.add("#include <sys/stat.h>")
        self.includes.add("#include <unistd.h>")
        self.includes.add('#include <stdio.h>')
        line2 = f'''if ({fd.text} >= 0) {{
                        struct stat {fd.text}_fstat; if (fstat({fd.text}, &{fd.text}_fstat) != 0) {{ perror(__FILE__ ":" LINE_STRING ":" "fstat"); return 3; }}
                        printf(",\\n{{"
                            "\\"syscall\\": \\"open\\", "
                            "\\"ret\\": %d, "
                            "\\"pathname\\": \\"{pathname}\\","
                            "\\"flags\\": {flags},"
                            "\\"mode\\": {mode},"
                            "\\"pid\\": %d,"
                            "\\"dev\\": %lu,"
                            "\\"ino\\": %lu,"
                            "\\"uid\\": %d,"
                            "\\"gid\\": %d,"
                            "\\"perms\\": %d"
                            "}}", {fd.text}, getpid(), (unsigned long)({fd.text}_fstat.st_dev), (unsigned long)({fd.text}_fstat.st_ino), {fd.text}_fstat.st_uid, {fd.text}_fstat.st_gid, {fd.text}_fstat.st_mode);
                    }} else {{
                        printf(",\\n{{"
                            "\\"syscall\\": \\"open\\", "
                            "\\"ret\\": %d, "
                            "\\"pathname\\": \\"{pathname}\\","
                            "\\"flags\\": {flags},"
                            "\\"mode\\": {mode},"
                            "\\"pid\\": %d"
                            "}}", {fd.text}, getpid());
                    }}'''

        self.syscall_lines.append(line1 + '\n' + line2)

        return fd

    def openat(self, dirfd: Expression, pathname: str, flags: int, mode: int, fatal: bool = False):
        assert '"' not in pathname

        self.includes.add('#include <fcntl.h>')
        self.includes.add('#include <unistd.h>')
        self.includes.add('#include <sys/syscall.h>')
        self.includes.add('#include <sys/stat.h>')

        self.includes.add('#include <sys/types.h>')
        flags_expr = self.openflags2expr(flags)
        syscall = f'syscall(SYS_openat, {dirfd.text}, "{pathname}", {flags_expr.text}, 0{mode:0o})'

        fd = self.bound_value_as_int(prefix='fd')

        if fatal:

            self.includes.add('#include <stdio.h>')
            line1 = f'if (({fd.text} = {syscall}) < 0) {{ perror(__FILE__ ":" LINE_STRING ":" "{pathname}"); return 2; }}'
        else:

            line1 = f'{fd.text} = {syscall};'

        self.includes.add("#include <sys/types.h>")
        self.includes.add("#include <sys/stat.h>")
        self.includes.add("#include <unistd.h>")
        self.includes.add('#include <stdio.h>')
        line2 = f'''if ({fd.text} >= 0) {{
                        struct stat {fd.text}_fstat; if (fstat({fd.text}, &{fd.text}_fstat) != 0) {{ perror(__FILE__ ":" LINE_STRING ":" "fstat"); return 3; }}
                        printf(",\\n{{"
                            "\\"syscall\\": \\"openat\\", "
                            "\\"ret\\": %d, "
                            "\\"dfd\\": %d,"
                            "\\"pathname\\": \\"{pathname}\\","
                            "\\"flags\\": {flags},"
                            "\\"mode\\": {mode},"
                            "\\"pid\\": %d,"
                            "\\"dev\\": %lu,"
                            "\\"ino\\": %lu,"
                            "\\"uid\\": %d,"
                            "\\"gid\\": %d,"
                            "\\"perms\\": %d"
                            "}}", {fd.text}, {dirfd.text}, getpid(), (unsigned long)({fd.text}_fstat.st_dev), (unsigned long)({fd.text}_fstat.st_ino), {fd.text}_fstat.st_uid, {fd.text}_fstat.st_gid, {fd.text}_fstat.st_mode);
                    }} else {{
                        printf(",\\n{{"
                            "\\"syscall\\": \\"openat\\", "
                            "\\"ret\\": %d, "
                            "\\"dfd\\": %d,"
                            "\\"pathname\\": \\"{pathname}\\","
                            "\\"flags\\": {flags},"
                            "\\"mode\\": {mode},"
                            "\\"pid\\": %d"
                            "}}", {fd.text}, {dirfd.text}, getpid());
                    }}'''
        self.syscall_lines.append(line1 + '\n' + line2)

        return fd

    def creat(self, pathname: str, mode: int, fatal: bool = False):
        assert '"' not in pathname

        self.includes.add('#include <unistd.h>')
        self.includes.add('#include <sys/syscall.h>')
        syscall = f'syscall(SYS_creat, "{pathname}", 0{mode:0o})'

        fd = self.bound_value_as_int(prefix='fd')

        if fatal:

            self.includes.add('#include <stdio.h>')
            line1 = f'if (({fd.text} = {syscall}) < 0) {{ perror(__FILE__ ":" LINE_STRING ":" "{pathname}"); return 2; }}'

        else:

            line1 = f'{fd.text} = {syscall};'

        self.includes.add("#include <sys/types.h>")
        self.includes.add("#include <sys/stat.h>")
        self.includes.add("#include <unistd.h>")
        self.includes.add('#include <stdio.h>')
        line2 = f'''if ({fd.text} >= 0) {{
                        struct stat {fd.text}_fstat; if (fstat({fd.text}, &{fd.text}_fstat) != 0) {{ perror(__FILE__ ":" LINE_STRING ":" "fstat"); return 3; }}
                        printf(",\\n{{"
                            "\\"syscall\\": \\"creat\\", "
                            "\\"ret\\": %d, "
                            "\\"pathname\\": \\"{pathname}\\","
                            "\\"mode\\": {mode},"
                            "\\"pid\\": %d,"
                            "\\"dev\\": %lu,"
                            "\\"ino\\": %lu,"
                            "\\"uid\\": %d,"
                            "\\"gid\\": %d,"
                            "\\"perms\\": %d"
                            "}}", {fd.text}, getpid(), (unsigned long)({fd.text}_fstat.st_dev), (unsigned long)({fd.text}_fstat.st_ino), {fd.text}_fstat.st_uid, {fd.text}_fstat.st_gid, {fd.text}_fstat.st_mode);
                    }} else {{
                        printf(",\\n{{"
                            "\\"syscall\\": \\"creat\\", "
                            "\\"ret\\": %d, "
                            "\\"pathname\\": \\"{pathname}\\","
                            "\\"mode\\": {mode},"
                            "\\"pid\\": %d"
                            "}}", {fd.text}, getpid());
                    }}'''
        self.syscall_lines.append(line1 + '\n' + line2)

        return fd

    def mkdir(self, pathname: str, mode: int, fatal: bool = False):
        assert '"' not in pathname

        self.includes.add('#include <unistd.h>')
        self.includes.add('#include <sys/syscall.h>')
        syscall = f'syscall(SYS_mkdir, "{pathname}", 0{mode:0o})'

        retval = self.bound_value_as_int()

        if fatal:

            self.includes.add('#include <stdio.h>')
            line1 = f'if (({retval.text} = {syscall}) != 0) {{ perror(__FILE__ ":" LINE_STRING ":" "mkdir"); return 2;}}'
        
        else:

            line1 = f'{retval.text} = {syscall};'

        self.includes.add("#include <sys/types.h>")
        self.includes.add("#include <sys/stat.h>")
        self.includes.add("#include <unistd.h>")
        self.includes.add('#include <stdio.h>')
        line2 = f'''if ({retval.text} >= 0) {{
                        struct stat {retval.text}_stat; if (stat("{pathname}", &{retval.text}_stat) != 0) {{ perror(__FILE__ ":" LINE_STRING ":" "stat"); return 3; }}
                        printf(",\\n{{"
                            "\\"syscall\\": \\"mkdir\\", "
                            "\\"ret\\": %d, "
                            "\\"pathname\\": \\"{pathname}\\","
                            "\\"mode\\": {mode},"
                            "\\"pid\\": %d,"
                            "\\"dev\\": %lu,"
                            "\\"ino\\": %lu,"
                            "\\"uid\\": %d,"
                            "\\"gid\\": %d,"
                            "\\"perms\\": %d"
                            "}}", {retval.text}, getpid(), (unsigned long)({retval.text}_stat.st_dev), (unsigned long)({retval.text}_stat.st_ino), {retval.text}_stat.st_uid, {retval.text}_stat.st_gid, {retval.text}_stat.st_mode);
                    }} else {{
                        printf(",\\n{{"
                            "\\"syscall\\": \\"mkdir\\", "
                            "\\"ret\\": %d, "
                            "\\"pathname\\": \\"{pathname}\\","
                            "\\"mode\\": {mode},"
                            "\\"pid\\": %d"
                            "}}", {retval.text}, getpid());
                    }}'''
        self.syscall_lines.append(line1 + '\n' + line2)

    def chmod(self, pathname: str, mode: int, fatal: bool = False):
        assert '"' not in pathname

        self.includes.add("#include <unistd.h>")
        self.includes.add("#include <sys/syscall.h>")
        self.includes.add("#include <sys/stat.h>")
        syscall = f'syscall(SYS_chmod, "{pathname}", 0{mode:0o})'

        retval = self.bound_value_as_int()

        if fatal:

            self.includes.add('#include <stdio.h>')
            line1 = f'if (({retval.text} = {syscall}) != 0) {{ perror(__FILE__ ":" LINE_STRING ":" "chmod"); return 2; }}'
        
        else:

            line1 = f'{retval.text} = {syscall};'

        self.includes.add("#include <sys/types.h>")
        self.includes.add("#include <sys/stat.h>")
        self.includes.add("#include <unistd.h>")
        self.includes.add('#include <stdio.h>')
        line2 = f'''if ({retval.text} >= 0) {{
                        struct stat {retval.text}_stat; if (stat("{pathname}", &{retval.text}_stat) != 0) {{ perror(__FILE__ ":" LINE_STRING ":" "stat"); return 3; }}
                        printf(",\\n{{"
                            "\\"syscall\\": \\"chmod\\", "
                            "\\"ret\\": %d, "
                            "\\"pathname\\": \\"{pathname}\\","
                            "\\"mode\\": {mode},"
                            "\\"pid\\": %d,"
                            "\\"perms\\": %d"
                            "}}", {retval.text}, getpid(), {retval.text}_stat.st_mode);
                    }} else {{
                        printf(",\\n{{"
                            "\\"syscall\\": \\"chmod\\", "
                            "\\"ret\\": %d, "
                            "\\"pathname\\": \\"{pathname}\\","
                            "\\"mode\\": {mode},"
                            "\\"pid\\": %d"
                            "}}", {retval.text}, getpid());
                    }}'''
        self.syscall_lines.append(line1 + '\n' + line2)

    def fchmod(self, fd: Expression, mode: int, fatal: bool = False):
        self.includes.add("#include <unistd.h>")
        self.includes.add("#include <sys/syscall.h>")
        self.includes.add("#include <sys/stat.h>")
        syscall = f'syscall(SYS_fchmod, {fd.text}, 0{mode:0o})'

        retval = self.bound_value_as_int(prefix = 'fd')

        if fatal:

            self.includes.add('#include <stdio.h>')
            line1 = f'if (({retval.text} = {syscall}) != 0) {{ perror(__FILE__ ":" LINE_STRING ":" "fchmod"); return 2; }}'
        
        else:

            line1 = f'{retval.text} = {syscall};'

        self.includes.add("#include <sys/types.h>")
        self.includes.add("#include <sys/stat.h>")
        self.includes.add("#include <unistd.h>")
        self.includes.add('#include <stdio.h>')
        line2 = f'''if ({retval.text} >= 0) {{
                        struct stat {retval.text}_fstat; if (fstat({fd.text}, &{retval.text}_fstat) != 0) {{ perror(__FILE__ ":" LINE_STRING ":" "fstat"); return 3; }}
                        printf(",\\n{{"
                            "\\"syscall\\": \\"fchmod\\", "
                            "\\"ret\\": %d, "
                            "\\"fd\\": %d,"
                            "\\"mode\\": {mode},"
                            "\\"pid\\": %d,"
                            "\\"perms\\": %d"
                            "}}", {retval.text}, {fd.text}, getpid(), {retval.text}_fstat.st_mode);
                    }} else {{
                        printf(",\\n{{"
                            "\\"syscall\\": \\"fchmod\\", "
                            "\\"ret\\": %d, "
                            "\\"fd\\": %d,"
                            "\\"mode\\": {mode},"
                            "\\"pid\\": %d"
                            "}}", {retval.text}, {fd.text}, getpid());
                    }}'''
        self.syscall_lines.append(line1 + '\n' + line2)


    def chdir(self, pathname: str, fatal: bool = False):
        assert '"' not in pathname

        self.includes.add("#include <unistd.h>")
        self.includes.add("#include <sys/syscall.h>")
        syscall = f'syscall(SYS_chdir, "{pathname}")'

        retval = self.bound_value_as_int()

        if fatal:

            self.includes.add('#include <stdio.h>')
            line1 = f'if (({retval.text} = {syscall}) != 0) {{ perror(__FILE__ ":" LINE_STRING ":" "chdir"); return 2; }}'
        
        else:

            line1 = f'{retval.text} = {syscall};'

        self.includes.add("#include <sys/types.h>")
        self.includes.add("#include <sys/stat.h>")
        self.includes.add("#include <unistd.h>")
        self.includes.add('#include <stdio.h>')
        line2 = f'''printf(",\\n{{"
                            "\\"syscall\\": \\"chdir\\", "
                            "\\"ret\\": %d, "
                            "\\"dir\\": \\"{pathname}\\","
                            "\\"pid\\": %d"
                            "}}", {retval.text}, getpid());'''

        self.syscall_lines.append(line1 + '\n' + line2)

    def fchdir(self, fd: Expression, fatal: bool = False):
        self.includes.add("#include <unistd.h>")
        self.includes.add("#include <sys/syscall.h>")
        syscall = f'syscall(SYS_fchdir, {fd.text})'

        retval = self.bound_value_as_int()

        if fatal:

            self.includes.add('#include <stdio.h>')
            line1 = f'if (({retval.text} = {syscall}) != 0) {{ perror(__FILE__ ":" LINE_STRING ":" "fchdir"); return 2; }}'
        
        else:

            line1 = f'{retval.text} = {syscall};'

        self.includes.add("#include <sys/types.h>")
        self.includes.add("#include <sys/stat.h>")
        self.includes.add("#include <unistd.h>")
        self.includes.add('#include <stdio.h>')
        line2 = f'''printf(",\\n{{"
                            "\\"syscall\\": \\"fchdir\\", "
                            "\\"ret\\": %d, "
                            "\\"fd\\": %d,"
                            "\\"pid\\": %d"
                            "}}", {retval.text}, {fd.text}, getpid());'''

        self.syscall_lines.append(line1 + '\n' + line2)

    def chown(self, pathname: str, uid: Expression, gid: int, fatal: bool = False):
        assert '"' not in pathname

        self.includes.add("#include <unistd.h>")
        self.includes.add("#include <sys/syscall.h>")
        syscall = f'syscall(SYS_chown, "{pathname}", {uid.text}, {gid})'

        retval = self.bound_value_as_int()

        if fatal:

            self.includes.add('#include <stdio.h>')
            line1 = f'if (({retval.text} = {syscall}) != 0) {{ perror(__FILE__ ":" LINE_STRING ":" "chown"); return 2; }}'
        
        else:

            line1 = f'{retval.text} = {syscall};'

        self.includes.add("#include <sys/types.h>")
        self.includes.add("#include <sys/stat.h>")
        self.includes.add("#include <unistd.h>")
        self.includes.add('#include <stdio.h>')
        line2 = f'''if ({retval.text} >= 0) {{
                        struct stat {retval.text}_stat; if (stat("{pathname}", &{retval.text}_stat) != 0) {{ perror(__FILE__ ":" LINE_STRING ":" "stat"); return 3; }}
                        printf(",\\n{{"
                            "\\"syscall\\": \\"chown\\", "
                            "\\"ret\\": %d, "
                            "\\"pathname\\": \\"{pathname}\\","
                            "\\"owner\\": %d,"
                            "\\"group\\": %d,"
                            "\\"pid\\": %d,"
                            "\\"perms\\": %d"
                            "}}", {retval.text}, {uid.text}, {gid}, getpid(), {retval.text}_stat.st_mode);
                    }} else {{
                        printf(",\\n{{"
                            "\\"syscall\\": \\"chown\\", "
                            "\\"ret\\": %d, "
                            "\\"pathname\\": \\"{pathname}\\","
                            "\\"owner\\": %d,"
                            "\\"group\\": %d,"
                            "\\"pid\\": %d"
                            "}}", {retval.text}, {uid.text}, {gid}, getpid());
                    }}'''
        self.syscall_lines.append(line1 + '\n' + line2)

    def fchown(self, fd: Expression, uid: Expression, gid: int, fatal: bool = False):
        self.includes.add("#include <unistd.h>")
        self.includes.add("#include <sys/syscall.h>")
        syscall = f'syscall(SYS_fchown, {fd.text}, {uid.text}, {gid})'

        retval = self.bound_value_as_int()

        if fatal:

            self.includes.add('#include <stdio.h>')
            line1 = f'if (({retval.text} = {syscall}) != 0) {{ perror(__FILE__ ":" LINE_STRING ":" "fchown"); return 2; }}'
        
        else:

            line1 = f'{retval.text} = {syscall};'

        self.includes.add("#include <sys/types.h>")
        self.includes.add("#include <sys/stat.h>")
        self.includes.add("#include <unistd.h>")
        self.includes.add('#include <stdio.h>')
        line2 = f'''if ({retval.text} >= 0) {{
                        struct stat {retval.text}_stat; if (fstat({fd.text}, &{retval.text}_stat) != 0) {{ perror(__FILE__ ":" LINE_STRING ":" "stat"); return 3; }}
                        printf(",\\n{{"
                            "\\"syscall\\": \\"fchown\\", "
                            "\\"ret\\": %d, "
                            "\\"fd\\": %d,"
                            "\\"owner\\": %d,"
                            "\\"group\\": %d,"
                            "\\"pid\\": %d,"
                            "\\"perms\\": %d"
                            "}}", {retval.text}, {fd.text}, {uid.text}, {gid}, getpid(), {retval.text}_stat.st_mode);
                    }} else {{
                        printf(",\\n{{"
                            "\\"syscall\\": \\"fchown\\", "
                            "\\"ret\\": %d, "
                            "\\"fd\\": %d,"
                            "\\"owner\\": %d,"
                            "\\"group\\": %d,"
                            "\\"pid\\": %d"
                            "}}", {retval.text}, {fd.text}, {uid.text}, {gid}, getpid());
                    }}'''
        self.syscall_lines.append(line1 + '\n' + line2)

    def getxattr(self, path: str, name: str, value: Expression, size: int, fatal: bool = False):
        assert '"' not in path
        assert '"' not in name

        self.includes.add("#include <unistd.h>")
        self.includes.add("#include <sys/types.h>")
        self.includes.add("#include <sys/xattr.h>")
        self.includes.add("#include <sys/syscall.h>")
        syscall = f'syscall(SYS_getxattr, "{path}", "{name}", {value.text}, {size})'

        retval = self.bound_value_as_int()

        if fatal:

            self.includes.add('#include <stdio.h>')
            line1 = f'if (({retval.text} = {syscall}) != 0) {{ perror(__FILE__ ":" LINE_STRING ":" "getxattr"); return 2; }}'
        
        else:

            line1 = f'{retval.text} = {syscall};'

        self.includes.add("#include <sys/types.h>")
        self.includes.add("#include <sys/stat.h>")
        self.includes.add("#include <unistd.h>")
        self.includes.add('#include <stdio.h>')
        line2 = f'''if ({retval.text} >= 0) {{
                        char __value[{size * 2 + 1}] = {{0}};
                        for (int __i = 0; __i < {retval.text}; ++__i) {{
                            sprintf(&__value[__i * 2], "%02x", 0xff & ({value.text}[__i]));
                        }}
                        printf(",\\n{{"
                            "\\"syscall\\": \\"getxattr\\", "
                            "\\"ret\\": %d, "
                            "\\"pathname\\": \\"{path}\\","
                            "\\"name\\": \\"{name}\\","
                            "\\"size\\": %d,"
                            "\\"pid\\": %d,"
                            "\\"value\\": \\"%s\\""
                            "}}", {retval.text}, {size}, getpid(), __value);
                    }} else {{
                        printf(",\\n{{"
                            "\\"syscall\\": \\"getxattr\\", "
                            "\\"ret\\": %d, "
                            "\\"pathname\\": \\"{path}\\","
                            "\\"name\\": \\"{name}\\","
                            "\\"size\\": %d,"
                            "\\"pid\\": %d"
                            "}}", {retval.text}, {size}, getpid());
                    }}'''
        self.syscall_lines.append(line1 + '\n' + line2)

    def setxattr(self, path: str, name: str, value: bytes, size: int, flags: int, fatal: bool = False):
        assert '"' not in path
        assert '"' not in name
        self.includes.add("#include <unistd.h>")
        self.includes.add("#include <sys/types.h>")
        self.includes.add("#include <sys/xattr.h>")
        self.includes.add("#include <sys/syscall.h>")
        flags_expr = self.xattrflags2expr(flags)
        c_value_literal = ''.join(f'\\x{v:0x}' for v in value)
        py_value_literal = ''.join(f'{v:0x}' for v in value)
        syscall = f'syscall(SYS_setxattr, "{path}", "{name}", "{c_value_literal}", {size}, {flags_expr.text})'

        retval = self.bound_value_as_int()

        if fatal:

            self.includes.add('#include <stdio.h>')
            line1 = f'if (({retval.text} = {syscall}) != 0) {{ perror(__FILE__ ":" LINE_STRING ":" "setxattr"); return 2; }}'

        else:
 
            line1 = f'{retval.text} = {syscall};'

        self.includes.add("#include <sys/types.h>")
        self.includes.add("#include <sys/stat.h>")
        self.includes.add("#include <unistd.h>")
        self.includes.add('#include <stdio.h>')
        line2 = f'''printf(",\\n{{"
                            "\\"syscall\\": \\"setxattr\\", "
                            "\\"ret\\": %d, "
                            "\\"pathname\\": \\"{path}\\","
                            "\\"name\\": \\"{name}\\","
                            "\\"value\\": \\"{py_value_literal}\\","
                            "\\"size\\": %d,"
                            "\\"flags\\": %d,"
                            "\\"pid\\": %d"
                            "}}", {retval.text}, {size}, {flags}, getpid());'''
        self.syscall_lines.append(line1 + '\n' + line2)

    def execve(self, exeFile: MonitoredExeFile, argv: Expression, envp: Expression, fatal: bool = False):
        assert '"' not in exeFile.path
        self.includes.add("#include <unistd.h>")
        self.includes.add("#include <sys/syscall.h>")
        syscall = f'syscall(SYS_execve, "{exeFile.path}", {argv.text}, {envp.text})'

        retval = self.bound_value_as_int()

        line0 = 'printf(",\\n"); fflush(stdout); '

        if fatal:
 
            self.includes.add('#include <stdio.h>')
            line1 = f'if (({retval.text} = {syscall}) != 0) {{ perror(__FILE__ ":" LINE_STRING ":" "{exeFile.path}"); return 2; }}'
 
        else:

            line1 = f'{retval.text} = {syscall};'

        self.includes.add('#include <stdio.h>')
        self.includes.add('#include <unistd.h>')
        line2 = f'''printf("{{"
                        "\\"syscall\\": \\"execve\\", "
                        "\\"ret\\": %d, "
                        "\\"pathname\\": \\"{exeFile.path}\\","
                        "\\"pid\\": %d"
                        "}}", {retval.text}, getpid());'''

        self.syscall_lines.append(line0 + '\n' + line1 + '\n' + line2)

    def link(self, oldpath: str, newpath: str, fatal: bool = False):
        assert '"' not in oldpath
        assert '"' not in newpath
        self.includes.add("#include <unistd.h>")
        self.includes.add("#include <sys/syscall.h>")
        syscall = f'syscall(SYS_link, "{oldpath}", "{newpath}")'

        retval = self.bound_value_as_int()

        if fatal:
 
            self.includes.add('#include <stdio.h>')
            line1 = f'if (({retval.text} = {syscall}) != 0) {{ perror(__FILE__ ":" LINE_STRING ":" "link"); return 2; }}'
 
        else:
 
            line1 = f'{retval.text} = {syscall};'

        self.includes.add("#include <sys/types.h>")
        self.includes.add("#include <sys/stat.h>")
        self.includes.add("#include <unistd.h>")
        self.includes.add('#include <stdio.h>')
        line2 = f'''printf(",\\n{{"
                            "\\"syscall\\": \\"link\\", "
                            "\\"ret\\": %d, "
                            "\\"oldname\\": \\"{oldpath}\\","
                            "\\"newname\\": \\"{newpath}\\","
                            "\\"pid\\": %d"
                            "}}", {retval.text}, getpid());'''
        self.syscall_lines.append(line1 + '\n' + line2)

    def unlink(self, pathname: str, fatal: bool = False):
        assert '"' not in pathname

        self.includes.add("#include <unistd.h>")
        self.includes.add("#include <sys/syscall.h>")
        syscall = f'syscall(SYS_unlink, "{pathname}")'

        retval = self.bound_value_as_int()

        if fatal:

            self.includes.add('#include <stdio.h>')
            line1 = f'if (({retval.text} = {syscall}) != 0) {{ perror(__FILE__ ":" LINE_STRING ":" "unlink"); return 2; }}'
        
        else:

            line1 = f'{retval.text} = {syscall};'

        self.includes.add("#include <sys/types.h>")
        self.includes.add("#include <sys/stat.h>")
        self.includes.add("#include <unistd.h>")
        self.includes.add('#include <stdio.h>')
        line2 = f'''printf(",\\n{{"
                            "\\"syscall\\": \\"unlink\\", "
                            "\\"ret\\": %d, "
                            "\\"pathname\\": \\"{pathname}\\","
                            "\\"pid\\": %d"
                            "}}", {retval.text}, getpid());'''
        self.syscall_lines.append(line1 + '\n' + line2)

    def rmdir(self, pathname: str, fatal: bool = False):
        assert '"' not in pathname

        self.includes.add("#include <unistd.h>")
        self.includes.add("#include <sys/syscall.h>")
        syscall = f'syscall(SYS_rmdir, "{pathname}")'

        retval = self.bound_value_as_int()

        if fatal:

            self.includes.add('#include <stdio.h>')
            line1 = f'if (({retval.text} = {syscall}) != 0) {{ perror(__FILE__ ":" LINE_STRING ":" "rmdir"); return 2; }}'
        
        else:

            line1 = f'{retval.text} = {syscall};'

        self.includes.add("#include <sys/types.h>")
        self.includes.add("#include <sys/stat.h>")
        self.includes.add("#include <unistd.h>")
        self.includes.add('#include <stdio.h>')
        line2 = f'''printf(",\\n{{"
                            "\\"syscall\\": \\"rmdir\\", "
                            "\\"ret\\": %d, "
                            "\\"pathname\\": \\"{pathname}\\","
                            "\\"pid\\": %d"
                            "}}", {retval.text}, getpid());'''
        self.syscall_lines.append(line1 + '\n' + line2)

    def close(self, fd: Expression, fatal: bool = False):
        self.includes.add('#include <unistd.h>')
        self.includes.add('#include <sys/syscall.h>')
        syscall = f'syscall(SYS_close, {fd.text})'

        retval = self.bound_value_as_int()

        if fatal:

            self.includes.add('#include <stdio.h>')
            line1 = f'if (({retval.text} = {syscall}) != 0) {{ perror(__FILE__ ":" LINE_STRING ":" "close"); return 2; }}'
        
        else:

            line1 = f'{retval.text} = {syscall};'

        self.includes.add("#include <sys/types.h>")
        self.includes.add("#include <sys/stat.h>")
        self.includes.add("#include <unistd.h>")
        self.includes.add('#include <stdio.h>')
        line2 = f'''printf(",\\n{{"
                            "\\"syscall\\": \\"close\\", "
                            "\\"ret\\": %d, "
                            "\\"fd\\": %d,"
                            "\\"pid\\": %d"
                            "}}", {retval.text}, {fd.text}, getpid());'''
        self.syscall_lines.append(line1 + '\n' + line2)

    def exit(self, status: int):
        self.includes.add('#include <unistd.h>')
        self.includes.add('#include <sys/syscall.h>')
        
        line1 = f'''printf(",\\n{{"
                            "\\"syscall\\": \\"exit\\", "
                            "\\"ret\\": 0, "
                            "\\"pid\\": %d"
                            "}}", getpid()); fflush(stdout);'''
        line2 = f'syscall(SYS_exit, {status});'

        self.syscall_lines.append(line1 + '\n' + line2)

    def openflags2expr(self, flags: int) -> Expression:
        # check: if any bit of "e" is 1, then it has been translated
        assert (flags & ~(reduce(lambda x, y: (x | y), FileFlags.keys(), 0))) == 0
        assert O_RDONLY == 0
        if (flags & O_WRONLY) != 0:
            e = FileFlags[O_WRONLY]
        elif (flags & O_RDWR) != 0:
            e = FileFlags[O_RDWR]
        else:
            e = FileFlags[O_RDONLY]
        return Expression(
            e + (''.join([' | ' + flag for f, flag in FileFlags.items() if (flags & f) != 0])))

    def xattrflags2expr(self, flags: int) -> Expression:
        if flags == 0:
            return Expression('0')
        e = (' | '.join([flag for f, flag in XattrFlags.items() if (flags & f) != 0]))
        # check: if any bit of "e" is 1, then it has been translated
        assert (flags & ~(reduce(lambda x, y: (x | y), XattrFlags.keys(), 0))) == 0
        return Expression(e)
