from dataclasses import dataclass, field
from os.path import dirname, isabs


class SnapshotBuilder:

    def __init__(self):
        self._init_users = list[str]()
        self._init_groups = list[str]()
        self._init_files = list[str]()
        self._init_dirs = list[str]()

    def add_user(self, user: str) -> None:
        self._init_users.append(user)
        if user in self._init_groups:
            raise ValueError('Group already added')
        self._init_groups.append(user)

    def add_group(self, group: str) -> None:
        if group in self._init_groups:
            raise ValueError('Group already added')
        self._init_groups.append(group)

    def add_file(self, path: str) -> None:
        if not isabs(path):
            raise ValueError('Absolute path required')
        if path in self._init_files:
            raise ValueError('File already added')
        self._init_files.append(path)
        while True:
            path = dirname(path)
            if path == '/':
                break
            if path not in self._init_dirs:
                self._init_dirs.append(path)

    def add_dir(self, path: str) -> None:
        if not isabs(path):
            raise ValueError('Absolute path required')
        if path in self._init_dirs:
            raise ValueError('Dir already added')
        self._init_dirs.append(path)
        while True:
            path = dirname(path)
            if path == '/':
                break
            if path not in self._init_dirs:
                self._init_dirs.append(path)

    def make_text_of_gatherinfo_file(self):
        root = f'stat --format=%n,%d,%i,%u,%g,%f /'

        users = [f'echo {u}:$(id -u {u}):$(id -g {u}):$(id -G {u})' for u in self._init_users]
        groups = [f'getent group {" ".join(self._init_groups)}'] if len(self._init_groups) > 0 else []

        files_stat = [f'stat --format=%n,%d,%i,%u,%g,%f {" ".join(self._init_files)}'] if len(self._init_files) > 0 else []
        files_attrs = [f'getfattr --absolute-names -d -e hex {" ".join(self._init_files)}'] if len(self._init_files) > 0 else []
        files_acl = [f'getfacl -n -p -e {" ".join(self._init_files)}'] if len(self._init_files) > 0 else []

        self._init_dirs.sort() # sorting moves parent folder earlier in the list
        dirs_stat = [f'stat --format=%n,%d,%i,%u,%g,%f {" ".join(self._init_dirs)}'] if len(self._init_dirs) > 0 else []
        dirs_attrs = [f'getfattr --absolute-names -d -e hex {" ".join(self._init_dirs)}'] if len(self._init_dirs) > 0 else []
        dirs_acl = [f'getfacl -n -p -e {" ".join(self._init_dirs)}'] if len(self._init_dirs) > 0 else []

        return [root, *groups, *users, *dirs_stat, *dirs_attrs, 'echo "<>"', 
                    *files_stat, *files_attrs, 'echo "<>"',
                    *dirs_acl, *files_acl]
