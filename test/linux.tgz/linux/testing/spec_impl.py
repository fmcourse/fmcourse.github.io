from contextlib import contextmanager
from datetime import datetime, timezone
from hashlib import sha256
import io
import json
from os.path import basename, isabs
from pathlib import Path
from shutil import copytree
import subprocess
import sys
import tempfile
import textwrap
from typing import Any, Iterator

from testing.kernel_program_maker import KernelProgramMaker, MonitoredExeFile
from tests.spec import LinuxTestSpec, ProgramMakerTextProducer, TextProducer


class LinuxTestSpecImpl(LinuxTestSpec):

    def __init__(self, nodeid: str, testpath: Path):
        super().__init__()
        self._nodeid = nodeid
        self._testpath = testpath
        self._setup_commands = list[str]()
        self._additional_files = dict[str, str]()
        self._label = sha256(nodeid.encode()).hexdigest()[:10]


    def make_user(self,
                user: str,
                supplementary_groups: None | list[str] = None) -> None:
        if not supplementary_groups:
            self.add_setup(f'useradd {user}')
        else:
            self.add_setup(f'useradd -G {",".join(supplementary_groups)} {user}')

    def make_group(self, group: str) -> None:
        self.add_setup(f'groupadd {group}')

    def make_file(self,
                 path: str,
                 owner: str,
                 group: str,
                 mode: int) -> None:
        if not isabs(path):
            raise ValueError('Relative paths are not supported')
        self.add_setup(f'touch {path}')
        self.add_setup(f'chown {owner}:{group} {path}')
        self.add_setup(f'chmod {mode:0o} {path}')
        

    def make_dir(self,
                 path: str,
                 owner: str,
                 group: str,
                 mode: int) -> None:
        if not isabs(path):
            raise ValueError('Relative paths are not supported')
        self.add_setup(f'mkdir {path}')
        self.add_setup(f'chown {owner}:{group} {path}')
        self.add_setup(f'chmod {mode:0o} {path}')
    
    def add_setup(self, setup_cmd: str) -> Any:
        self._setup_commands.append(setup_cmd)

    @contextmanager
    def make_program(self) -> Iterator[ProgramMakerTextProducer]:
        yield KernelProgramMaker()

    def compile(self, program_maker: TextProducer, path: str, make_file: bool=True) -> MonitoredExeFile:
        source_path = f'{path}.c'
        if basename(source_path) in self._additional_files:
            raise ValueError('Additional file redefined')

        program_text = program_maker.get_text()
        self._additional_files[basename(source_path)] = program_text
        if make_file:
            self.make_file(path, 'root', 'root', 0o777)
        self.add_setup(f'gcc -static -o {path} /progs/{basename(source_path)}')
        return MonitoredExeFile(path)


    @contextmanager
    def make_program_and_run(self, user: str, group: str, umask: int, runner: str = '<>', make_file: bool = True,
                             before_run: str|None=None, after_run: str|None=None):
        with self.make_program() as prog:
            yield prog
        exeFile = self.compile(prog, '/tst_prog', make_file)
        self.run(exeFile, user, group, umask, runner, before_run, after_run)


    def run(self, exeFile: MonitoredExeFile,
            user: str, group: str, umask: int, runner: str,
            before_run: str|None, after_run: str|None):

        # with self._run_with_preparing_image(exeFile=exeFile,
        #         user=user, group=group, umask=umask, runner=runner,
        #         before_run=before_run, after_run=after_run) as trace:

        with self._run_without_preparing_image(exeFile=exeFile,
                user=user, group=group, umask=umask, runner=runner,
                before_run=before_run, after_run=after_run) as trace:

            pass # TODO self._check(trace)


    @contextmanager
    def _run_with_preparing_image(self, exeFile: MonitoredExeFile,
            user: str, group: str, umask: int, runner: str,
            before_run: str|None, after_run: str|None):

        setup_cmd = ' && '.join(self._setup_commands)
        runner_cmd = runner.replace('<>', f'(chfn --other="umask={umask:0o}" {user}; /monitoring/monitor run sudo -HE -u {user} -g {group} {exeFile.path})')


        def main():

            build_image()

            if before_run:
                subprocess.run(['sudo', '/bin/bash'], input=before_run, encoding='utf-8', check=True)

            container_name = f"anis_{self._label}"
            proc = None
            try:
                proc = subprocess.Popen(['sudo', 'podman', 'run',
                            '--rm',
                            f'--name={container_name}',
                            '--cap-add=CAP_BPF', '--cap-add=CAP_SYS_ADMIN',
                            '-v', '/sys/fs/bpf:/sys/fs/bpf:rw',
                            '-v', '/sys/kernel:/sys/kernel:ro',
                            # '--pid=host',
                            # '--network=host',
                            # '--security-opt', 'label=disable',
                            f'anis:{self._label}'
                            ], stdout=subprocess.PIPE, text=True, bufsize=1, encoding='utf-8')

                if not proc.stdout:
                    raise ValueError('No stdout')

                yield proc.stdout
            except:
                subprocess.run(['sudo', 'podman', 'kill', container_name])
                raise
            finally:
                if proc:
                    if proc.stdout:
                        proc.stdout.close()
                    proc.wait(timeout=5)

                if after_run:
                    subprocess.run(['sudo', '/bin/bash'], input=after_run, encoding='utf-8')

        def build_image():

            if image_is_newer_than(self._testpath, Path('conftest.py'),
                                    *all_monitoring_files(),
                                    *all_py_files(Path('testing')),
                                    *all_files(Path('testing') / 'base_image')):
                return

            with tempfile.TemporaryDirectory() as base:

                container_file = make_text_of_container_file()
                base_path = Path(base)
                (base_path / 'Containerfile').write_text(container_file)
                (base_path / 'setup.sh').write_text(setup_cmd)
                copytree('monitoring', str(base_path / 'monitoring'))
                (base_path / 'progs').mkdir()
                for path, contents in self._additional_files.items():
                    (base_path / 'progs' / basename(path)).write_text(contents)

                subprocess.run(['sudo', 'podman', 'build',
                                '-t', f'anis:{self._label}',
                                base,
                                ], check=True)

        def all_files(parent: Path):
            return [p for p in parent.iterdir() if p.is_file()]

        def all_py_files(parent: Path):
            return [p for p in parent.iterdir() if p.is_file() and p.suffix == '.py']

        def all_monitoring_files():
            return [p for p in Path('monitoring').iterdir() if p.is_file()
                    and (p.name == 'Makefile' or
                            p.suffix in {'.c', 'h'} and not p.name.endswith('.skel.h'))]


        def image_is_newer_than(*paths: Path):
            image_ts = get_image_timestamp()
            return (image_ts is not None and
                    all(file.stat().st_mtime < image_ts for file in paths))


        def get_image_timestamp():

            proc = subprocess.run(['sudo', 'podman', 'image', 'inspect', f'anis:{self._label}', '--format="{{.Created}}'],
                                        stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, encoding='utf-8')
            if proc.returncode != 0:
                return None

            s_clean = proc.stdout.strip('"').replace(" UTC", "")
            time_part = s_clean.split(" +")[0]
            if '.' in time_part:
                date_part, micro_part = time_part.split('.')
                micro_part = micro_part[:6].ljust(6, '0') 
                time_part = f"{date_part}.{micro_part}"
            return (datetime.strptime(time_part, "%Y-%m-%d %H:%M:%S.%f")
                    .replace(tzinfo=timezone.utc)
                    .timestamp())



        def make_text_of_container_file():
            return textwrap.dedent(f"""
                FROM anis:base
                COPY ./ /
                RUN chmod +x /setup.sh && /setup.sh
                CMD {runner_cmd}""")


        return main()



    @contextmanager
    def _run_without_preparing_image(self, exeFile: MonitoredExeFile,
            user: str, group: str, umask: int, runner: str,
            before_run: str|None, after_run: str|None):

        container_name = f"anis_{self._label}"

        with tempfile.TemporaryDirectory() as base:

            base_path = Path(base)
            for path, contents in self._additional_files.items():
                (base_path / basename(path)).write_text(contents)

            runner_cmd = runner.replace('<>', f'(chfn --other="umask={umask:0o}" {user}; /monitoring/monitor run sudo -HE -u {user} -g {group} {exeFile.path})')

            if not before_run:

                # 1. run setup
                # 2. run runner

                cmd = ' && '.join(self._setup_commands + [runner_cmd])
                proc = None
                try:
                    print(f'run {self._nodeid} ...', file=sys.stderr, end=' ')
                    proc = subprocess.run(['sudo', 'podman', 'run',
                        '--rm',
                        '-i',
                        f'--name={container_name}',
                        '--cap-add=CAP_BPF', '--cap-add=CAP_SYS_ADMIN',
                        '-v', f'{base_path}:/progs:ro',
                        '-v', '/sys/fs/bpf:/sys/fs/bpf:rw',
                        '-v', '/sys/kernel:/sys/kernel:ro',
                        '-v', './monitoring:/monitoring:ro',
                        # '--cpu-period=10000',
                        # '--cpu-quota=10000',
                        # '--pid=host',
                        # '--network=none',
                        # '--security-opt', 'label=disable',
                        'anis:base',
                        '/bin/bash',
                        ], input=cmd, encoding='utf-8', check=True, capture_output=True)
                    if proc.stderr:
                        raise ValueError(proc.stderr)
                    print('ok', file=sys.stderr)

                    yield io.StringIO(proc.stdout)

                except:
                    subprocess.run(['sudo', 'podman', 'rm', '-f', container_name])
                    raise

            else:

                subprocess.run(['sudo', 'podman', 'run',
                    '-d',
                    '-i',
                    f'--name={container_name}',
                    '--cap-add=CAP_BPF', '--cap-add=CAP_SYS_ADMIN',
                    '-v', f'{base_path}:/progs:ro',
                    '-v', '/sys/fs/bpf:/sys/fs/bpf:rw',
                    '-v', '/sys/kernel:/sys/kernel:ro',
                    '-v', './monitoring:/monitoring:ro',
                    # '--pid=host',
                    # '--network=host',
                    # '--security-opt', 'label=disable',
                    'anis:base',
                    '/bin/bash'
                    ], check=True, stdout=subprocess.DEVNULL)

                try:
                    # 1. run setup
                    cmd = ' && '.join(self._setup_commands)
                    print('setup...', file=sys.stderr, end=' ')
                    proc = subprocess.run(['sudo', 'podman', 'exec',
                        '-i',
                        container_name,
                        '/bin/bash',
                        ], input=cmd, encoding='utf-8', check=True, capture_output=True)
                    if proc.stderr:
                        raise ValueError(proc.stderr)
                    info = proc.stdout
                    print('ok', file=sys.stderr)

                    # 2. run before_run
                    if before_run:
                        subprocess.run(['sudo', '/bin/bash'], input=before_run, encoding='utf-8', check=True)

                except:
                    subprocess.run(['sudo', 'podman', 'rm', '-f', container_name])
                    raise

                # 3. run runner
                proc = None
                try:
                    print(f'run {self._nodeid} ...', file=sys.stderr, end=' ')
                    proc = subprocess.run(['sudo', 'podman', 'exec',
                        '-i',
                        container_name,
                        '/bin/bash',
                        ], input=runner_cmd, encoding='utf-8', capture_output=True)
                    print('ok', file=sys.stderr)

                    if proc.stderr:
                        raise ValueError(proc.stderr)
                    if not proc.stdout:
                        raise ValueError('No stdout')

                    yield io.StringIO(info + proc.stdout)
                except:
                    subprocess.run(['sudo', 'podman', 'kill', container_name])
                    raise
                finally:
                    if proc:
                        print('end...', file=sys.stderr, end=' ')
                        subprocess.run(['sudo', 'podman', 'attach', '--no-stdin', container_name], stdout=subprocess.DEVNULL)
                        subprocess.run(['sudo', 'podman', 'rm', '-f', container_name], stdout=subprocess.DEVNULL)
                        print('ok', file=sys.stderr)

                    # 4. run after_run
                    if after_run:
                        subprocess.run(['sudo', '/bin/bash'], input=after_run, encoding='utf-8')
