FileFlags = {
    0o00000000: 'O_RDONLY',
    0o00000001: 'O_WRONLY',
    0o00000002: 'O_RDWR',

    0o00000100: 'O_CREAT',
    0o00000200: 'O_EXCL',
    0o00000400: 'O_NOCTTY',
    0o00001000: 'O_TRUNC',
    0o00002000: 'O_APPEND',
    0o00004000: 'O_NOBLOCK', # typo in the model? O_NO(N)BLOCK
    0o00010000: 'O_DSYNC',
    # 0o00020000: FASYNC, # no such a constant in the model
    0o00040000: 'O_DIRECT',
    0o00100000: 'O_LARGEFILE',
    0o00200000: 'O_DIRECTORY',
    0o00400000: 'O_NOFOLLOW',
    0o01000000: 'O_NOATIME',
    0o02000000: 'O_CLOEXEC',
    0o10000000: 'O_PATH',
}

XattrFlags = {
    0o1: 'XATTR_CREATE',
    0o2: 'XATTR_REPLACE',
}

