from multiprocessing import Pipe, Process
from multiprocessing.connection import Connection
import os
from subprocess import run
from pytest import fixture
from _pytest.fixtures import SubRequest # type: ignore
from typing import Any

@fixture
def t(request: SubRequest, monitor_loaded: Any):
    from testing.spec_impl import LinuxTestSpecImpl
    return LinuxTestSpecImpl(request.node.nodeid, request.node.path)


@fixture(scope='session')
def monitor_loaded():
    """
    Tests are not be cancelled immediately by "Cancel Test Run" in VSCode.
    There is a particular period when the button was already pressed but
    several containers were not finished. When all the things are finished,
    the monitor will be unloaded. So do not run tests immediately after
    the "Finished running tests!" message was appeared in "Test Results"! 
    """

    def loader_process(rcvc1: Connection, sndc1: Connection, rcvc2: Connection, sndc2: Connection):
        os.setsid()
        print('Loading monitor ...', end=' ')
        run(['sudo', 'make', '-s', '-C', 'monitoring', 'load'], check=True)
        print('ok')
        rcvc1.close()
        sndc2.close()
        sndc1.close() # loader is ready
        try:
            rcvc2.recv() # wait for closing conn2 (i.e. may unload)
        except EOFError:
            pass
        finally:
            print('Unloading monitor ...', end=' ')
            run(['sudo', 'make', '-s', '-C', 'monitoring', 'unload'], check=True)
            print('ok')

    rcvc1, sndc1 = Pipe(duplex=False)
    rcvc2, sndc2 = Pipe(duplex=False)
    loader = Process(target=loader_process, args=(rcvc1, sndc1, rcvc2, sndc2,),)
    loader.start()
    sndc1.close()
    rcvc2.close()
    try:
        rcvc1.recv() # wait while loading will be fully finished
    except EOFError:
        pass
    finally:
        yield
        sndc2.close()
        loader.join() # wait while unloading will be fully finished
